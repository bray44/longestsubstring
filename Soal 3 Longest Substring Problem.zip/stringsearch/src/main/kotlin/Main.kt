fun main() {
    println("Silahkan ketik string yang ingin dianalisa:")
    val str = readLine()!!
    var maxLength = 0
    var start = 0
    val charSet = mutableSetOf<Char>()

    for (end in str.indices) {
        if (charSet.contains(str[end])) {
            while (str[start] != str[end]) {
                charSet.remove(str[start])
                start++
            }
            start++
        } else {
            charSet.add(str[end])
            maxLength = maxOf(maxLength, end - start + 1)
        }
    }

    println("Panjang substring tanpa perulangan karakter adalah: $maxLength")
}
